package com.example.readmeSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadmeSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
